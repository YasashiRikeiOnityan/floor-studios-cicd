import boto3
import os
from datetime import datetime

# AWSリソース
cloudfront = boto3.client('cloudfront')
codepipeline = boto3.client('codepipeline')
# 環境変数
distribution_id = os.environ['DISTRIBUTION_ID']

def lambda_handler(event, context):    
    try:
        cloudfront.create_invalidation(
            DistributionId=distribution_id,
            InvalidationBatch={
                'Paths': {
                    'Quantity': 1,
                    'Items': ['/*']
                },
                'CallerReference': datetime.now().strftime('%Y%m%d%H%M%S')
            }
        )

        # CodePipelineに完了を伝達する
        codepipeline.put_job_success_result(jobId = event['CodePipeline.job']['id'])

        return {'statusCode': 200}

    except Exception:
        # CodePipelineに失敗を伝達する
        codepipeline.put_job_failure_result(jobId = event['CodePipeline.job']['id'])

        return {'statusCode': 500}
